﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Proj1
{
    //WRITE YOUR CODE BELOW.
    public static class IntExtensions
    {
        private static void findMinInteger(this Dictionary<string, int> TheMap)
        {
            var val = TheMap.OrderBy(k => k.Value).FirstOrDefault();
            Console.WriteLine("**********************************************");
            Console.WriteLine("Minimum Length is " + val.Value + " characters.");
            Console.WriteLine("**********************************************");
        }

        public static async void PopulateLengthsAsync(this Dictionary<string, int> TheMap, string[] myArray)
        {
            using (var client = new HttpClient())
            {
                for (int i = 0; i < myArray.Length; i++)
                {
                    string result = await client.GetStringAsync(myArray[i]);
                    int temp = result.Length;
                    TheMap.Add(myArray[i], temp);
                }
            }

            foreach (var item in TheMap)
            {
                Console.WriteLine(item.Key + " has " + item.Value + " characters");
            }

            findMinInteger(TheMap);
        }
    }





    public class Demo
    {
        //The array of strings of URLs
        private string[] stringifiedURLs = new string[] {
            "https://en.wikipedia.org/wiki/Animal",
            "https://en.wikipedia.org/wiki/Flower",
            "https://en.wikipedia.org/wiki/Color",
            "https://en.wikipedia.org/wiki/Fruit"
        };

        //Create a Dictionary and assign it to a private non-static variable 
        //named map. The variable map should store Key-Value pairs where:
        //a Key is a stringified URL 
        //a Value is the number of characters (of type int) present in that URL 
        //WRITE YOUR CODE BELOW.
        private Dictionary<string, int> map = new Dictionary<string, int>();


        public static void Main(string[] args)
        {
            //WRITE YOUR CODE BELOW.
            Demo d = new Demo();
            d.map.PopulateLengthsAsync(d.stringifiedURLs);

            Console.ReadKey(); //halt execution
        }
    }
}

/*
 * Output from the program is given below:

https://en.wikipedia.org/wiki/Animal has 540461 characters
https://en.wikipedia.org/wiki/Flower has 358431 characters
https://en.wikipedia.org/wiki/Color has 188352 characters
https://en.wikipedia.org/wiki/Fruit has 213078 characters
**********************************************
Minimum Length is 188352 characters
**********************************************

 */
