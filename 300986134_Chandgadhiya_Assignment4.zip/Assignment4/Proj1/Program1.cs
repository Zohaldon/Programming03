﻿using System;
using System.Linq;
using System.Collections.Generic;

/*
 * The Main method is already provided for you in this file 
 * for this project. You MUST NOT change this existing Main method.
 * 
 */

namespace Proj1
{
    public class Program1
    {
        public static Func<T1, T3> Compose1<T1, T2, T3>(Func<T1, T2> del1, Func<T2, T3> del2)
        {
            //WRITE THE CODE BELOW.
            return a => del2(del1(a));
        }
    }

    class Demo
    {
        public static void Main(string[] args)
        {
            Func<int, int> f1 = x => x + 1;
            Func<int, int> f2 = x => x + 2;
            Func<int, int> del3 = Program1.Compose1(f1, f2);

            int x1 = del3(39);
            Console.WriteLine("The value is " + x1);

            //-------------------

            Func<string, int> f11 = x => x.Length;
            Func<int, string> f21 = x => "The string length is " + x;
            Func<string, string> del31 = Program1.Compose1(f11, f21);

            string x2 = del31("Happy");
            Console.WriteLine(x2);

            Console.ReadKey(); //halt execution
        }
    }
}

/*
 *  OUTPUT from the above program is given below.
 *

The value is 42
The string length is 5


 *
 * 
 */
