﻿using System;
using System.Linq;
using System.Collections.Generic;

/*
 * The Main method is already provided for you in this file 
 * for this project. You MUST NOT change this existing Main method.
 * 
 */

namespace Proj2
{
    //DELETE THIS delegate declaration as well. 
    public delegate T4 MYDELEGATE<T1, T2, T3, T4>(T1 arg1, T2 arg2, T3 arg3);

    public class Program1
    {
        //WRITE THE METHOD HEADER FOR THE doWork METHOD BELOW.
        //Note: If you need to use a delegate class, you MUST NOT use 
        //any system-defined delegate classes. Instead, you must declare a  
        //custom generic delegate class named MYDELEGATE outside the 
        //Program1 class, within the namespace Proj2. You may then use 
        //the MYDELEGATE class if you need to.

        public static void doWork<T1, T2>(List<T1> list, T2 arg, MYDELEGATE<T1, T1, T2, bool> del)        
        { //start of method doWork
            T1 value1 = list.First();
            T1 value2 = list.Last();
            bool value = del(value1, value2, arg);
            Console.WriteLine("**********************");
            Console.WriteLine("value  has " + value);
            Console.WriteLine("value1 has " + value1);
            Console.WriteLine("value2 has " + value2);
            Console.WriteLine("arg    has " + arg);
        } //end of method doWork
		

        public static void Main(string[] args)
        {
            //Test-1
            List<int> list1 = new List<int>();
            list1.Add(1); list1.Add(2); list1.Add(3);
            doWork<int, string>(list1, 
                                "success", 
                                (x, y, z) => 
                                    {
                                        Console.WriteLine("**********************");
                                        Console.WriteLine(x + " != " + y);
                                        return x != y;
                                    } 
                                );

            //Test-2
            List<string> list2 = new List<string>();
            list2.Add("AB"); list2.Add("ABC"); list2.Add("ABCD");
            doWork<string, string>(list2, 
                                "failure", 
                                (x, y, z) =>
                                    {
                                        Console.WriteLine("**********************");
                                        Console.WriteLine(x + " == " + y);
                                        return x.Length == y.Length;
                                    }
                                );

            Console.ReadKey(); //halt execution
        }

}
}

/*
 *  OUTPUT from the above program is given below.
 *
 

**********************
1 != 3
**********************
value  has True
value1 has 1
value2 has 3
arg    has success
**********************
AB == ABCD
**********************
value  has False
value1 has AB
value2 has ABCD
arg    has failure



 *
 * 
 */

